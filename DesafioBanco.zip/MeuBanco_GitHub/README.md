# MeuBanco

Aplicação desktop em Java Swing para simular depósitos bancários.

## Funcionalidades

- Saldo inicial de R$ 500,00.
- Realização de depósitos.
- Atualização automática do saldo.
- Histórico de movimentações.
- Validação de campos vazios e valores inválidos.

## Estrutura

```text
src/main/java/br/gov/sp/cps/
├── Main.java
├── controllers/
│   └── BancoController.java
├── models/
│   └── ContaBancaria.java
└── views/
    └── TelaBanco.java
```

## Execução

Abra o projeto em uma IDE Java e execute a classe `Main.java`.
